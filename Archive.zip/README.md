Tech challenge for entry to hackeryou full-stack course - example of responsive front-end and API call.
